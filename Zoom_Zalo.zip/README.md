# Zoom -> Zalo Auto Scheduler (Chrome Extension)

Extension hẹn giờ tự động:
1. End cuộc họp Zoom.
2. Chuyển sang tab Zalo Web đang mở sẵn.
3. Bấm nút gửi tin nhắn (`.send-msg-btn`) trên Zalo.

## Tải nhanh bản ZIP

Tải source tại [tại đây](https://codeload.github.com/Huynd2097/Zoom_Zalo/zip/refs/heads/main).

Sau khi tải:
1. Giải nén file ZIP.
2. Bạn sẽ có thư mục dạng `Zoom_Zalo-main`.
3. Dùng chính thư mục này để nạp extension (`Load unpacked`).

## Cài đặt (Load unpacked)

1. Mở Chrome và vào `chrome://extensions`.
2. Bật `Developer mode`.
3. Chọn `Load unpacked`.
4. Trỏ đến thư mục đã giải nén (ví dụ: `Zoom_Zalo-main`).
5. Pin extension lên thanh công cụ (tuỳ chọn).

Cảnh báo chọn nhầm thư mục:
- Không chọn thư mục ngoài cùng chỉ chứa thư mục con.
- Không chọn file `.zip`.
- Hãy chọn đúng thư mục có file `manifest.json` nằm trực tiếp bên trong.
- Nếu Chrome báo lỗi `Manifest file is missing or unreadable`, gần như chắc chắn bạn đã chọn sai thư mục.

## Cách dùng

1. Mở sẵn tab Zoom meeting.
2. Mở sẵn tab Zalo Web (`https://chat.zalo.me`) và vào đúng cuộc chat cần gửi.
3. Nhập sẵn nội dung tin nhắn trong ô chat Zalo.
4. Mở extension popup, nhập thời gian hẹn, bấm **Bắt đầu hẹn giờ**.
5. Đến giờ, extension sẽ:
   - Chuyển sang tab Zoom và End meeting.
   - Chuyển sang tab Zalo và bấm Send.

## Tính năng

- Hẹn giờ theo phút/giây.
- Countdown trong popup extension.
- Countdown nổi trên trang (góc phải trên), có thể kéo thả và nhớ vị trí.
- Tự tìm tab Zoom/Zalo theo URL, không phụ thuộc tab đang mở lúc hết giờ.
- Dùng `chrome.alarms` để hẹn giờ ổn định hơn cho mốc dài.

## Lưu ý quan trọng

- Sau khi reload extension, nên reload lại tab Zoom và Zalo để content script inject mới nhất.
- Zalo hiện tại chỉ bấm Send, **không tự gõ nội dung**.
- Nếu chưa thấy countdown nổi, reload tab hiện tại.
- Chrome phải đang chạy tại thời điểm trigger.

## Hạn chế hiện tại

- Selector Zoom/Zalo có thể thay đổi khi UI của họ cập nhật.
- Nếu phiên đăng nhập Zoom/Zalo hết hạn, thao tác tự động sẽ fail.
- Nếu máy sleep đúng lúc hẹn, thời điểm chạy có thể bị trễ.

## Troubleshooting

### 1) Hẹn 10s chạy, 30s+ không chạy
Đã chuyển qua `chrome.alarms` để giảm lỗi này. Hãy chắc bạn đang dùng bản code mới nhất.

### 2) Chuyển qua Zalo nhưng không gửi
- Kiểm tra có đúng cuộc chat đang mở không.
- Kiểm tra nút gửi còn class `.send-msg-btn` không.
- Reload tab Zalo sau khi reload extension.

### 3) End Zoom không thành công
- Kiểm tra Zoom đang chạy trong iframe `#webclient` như bản hiện tại đang xử lý.
- Nếu Zoom đổi class/nút, cần cập nhật selector trong `content-scripts/zoom-content.js`.

### 4) Lỗi lệch ZID / Gửi nhầm sang Truyền file (My Documents)
- Lỗi xảy ra do Zalo tải trang chậm làm lưu nhầm ZID cũ của My Documents vào danh bạ của số điện thoại vừa tìm kiếm.
- Khắc phục: Đã được xử lý triệt để thông qua cơ chế kiểm tra tiêu đề khớp tên cuộc trò chuyện trước khi lấy ZID và hệ thống tự động dọn dẹp (self-healing) các trường bị nhiễm của tài khoản hệ thống khi danh bạ được tải.


## Cấu trúc chính

- `manifest.json`: cấu hình extension MV3.
- `background.js` + `background/`: service worker, scheduler, Chrome/CDP helper, contact mapping, hàng chờ tin nhắn và worker xử lý gửi tin, theo dõi phản hồi.
- `content-scripts/`: script chạy trên Zoom/Zalo.
- `popup/`: popup mở các màn chức năng.
- `batch-page/`: màn import, chỉnh tay dữ liệu/state, gửi tin nhắn từ hàng chờ, theo dõi phản hồi, export replies.
- `contacts-page/`: màn đồng bộ/xem/export mapping liên hệ Zalo.
- `shared/`: helper dùng chung cho các trang extension.
- `vendor/`: thư viện bên thứ ba.
- `test/`: script/screenshot phục vụ kiểm thử thủ công hoặc smoke test.
- `archive/`: file backup/debug cũ, không được manifest load.

## Ghi chú bảo trì

- Luồng gõ/gửi Zalo trong `background.js` dùng Chrome Debugger/CDP vì Zalo Web nhiều lần không nhận thao tác nhập/gửi bằng DOM event thường. Không mở DevTools trên tab Zalo khi chạy, nếu không sẽ gặp lỗi `Another debugger is already attached`.
- Worker gửi tin ưu tiên click hội thoại đang thấy trong sidebar theo `zid`. Nếu sidebar không render hội thoại đó, được fallback sang `chat.zalo.me/?c=zid`, nhưng luôn phải verify đúng `zid` và tên hiển thị trước khi gửi.
- `display_name` phải là tên đang hiển thị trên Zalo đã loại tag/nhãn như `Công việc`. Các đường sync contact, check chat hiện tại và match tên đều cần đi qua logic clean tên.
- `display_name` lấy từ DOM là nguồn chính thức. Khi DOM hiển thị tên khác với tên đã lưu trong contact map, hệ thống tự cập nhật storage. Đảm bảo khi người dùng đổi tên Zalo hoặc user sửa nickname, dữ liệu luôn được đồng bộ.
- Bảng gửi tin nhắn chỉ dùng 3 state người dùng: `pending`, `wait_reply`, `done`. Các state nội bộ như `sending`, `sent`, `skipped`, `error` phải được normalize khi hiển thị.
- Hàng chờ dùng một bảng chung lưu trong `chrome.storage.local`. Cột `wait_reply` là tùy chọn; dòng nào có giá trị `x` thì sau khi gửi sẽ chờ phản hồi, còn bỏ trống thì chỉ gửi và hoàn tất.
- Nếu không tìm thấy hội thoại theo `zid`, không set lỗi vĩnh viễn. Giữ dòng ở `pending`, đi tiếp list, hết vòng thì đợi 5 giây rồi thử lại.
- Không render lại bảng khi user đang sửa cell hoặc đang mở dropdown state. Trước đây polling 1 giây làm mất nội dung đang gõ và làm dropdown biến mất.
- Đồng bộ liên hệ (`syncVisibleContacts`) dùng hàm `scrollSidebarAndCollect` để scroll toàn bộ sidebar từ trên xuống dưới, thu thập mọi `.msg-item` tại mỗi vị trí scroll. Zalo dùng virtual scrolling nên chỉ render vài chục item tại 1 thời điểm; hàm scroll giải quyết giới hạn này.
- Test/smoke không được tự bịa contact, import CSV giả hoặc reset storage live. Chỉ dùng read-only hoặc snapshot/restore đầy đủ nếu thật sự cần.
- `sys_phone` (số điện thoại hệ thống dùng để đối chiếu) được tự động trích xuất từ tên hiển thị thô (trước khi làm sạch tên) nếu trường `phone` chính thức bị bỏ trống, đảm bảo việc tìm kiếm hội thoại và ánh xạ liên hệ không bị gián đoạn.


## Gợi ý publish

Nếu muốn phát hành public:
- Dọn lại tên/description/version trong `manifest.json`.
- Tạo icon extension đầy đủ kích thước.
- Test lại trên nhiều máy/tài khoản Zoom/Zalo.
- Đóng gói và publish qua Chrome Web Store.

## License

Bạn có thể thêm license tùy ý (MIT khuyến nghị cho dự án chia sẻ cộng đồng).

