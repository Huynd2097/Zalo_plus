
const template = \(() => {
    const normalize = (text) => (text || '').replace(/\\u00a0/g, ' ').replace(/\\s+/g, ' ').trim();
    return normalize('a  b');
})()\;
console.log(template);
console.log(eval(template));
