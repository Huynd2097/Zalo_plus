const summaryEl = document.getElementById('summary');
const statusEl = document.getElementById('status');
const statusTextEl = document.getElementById('statusText');
const statusCloseBtn = document.getElementById('statusCloseBtn');
const syncContactsBtn = document.getElementById('syncContactsBtn');
const reloadContactsBtn = document.getElementById('reloadContactsBtn');
const exportContactsBtn = document.getElementById('exportContactsBtn');
const clearContactsBtn = document.getElementById('clearContactsBtn');
const contactsBodyEl = document.getElementById('contactsBody');

let latestContacts = [];

function setStatus(text, isError = false) {
  const message = String(text || '').trim();
  statusTextEl.textContent = message;
  statusEl.classList.toggle('status-error', Boolean(isError));
  statusEl.style.display = message ? 'flex' : 'none';
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(resp || { ok: false, error: 'No response.' });
    });
  });
}

function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatTime(value) {
  const time = Number(value || 0);
  return time ? new Date(time).toLocaleString('vi-VN') : '';
}

function renderContacts(contacts) {
  latestContacts = contacts || [];
  summaryEl.textContent = `${latestContacts.length} liên hệ đã lưu`;
  contactsBodyEl.innerHTML = latestContacts.map((contact) => {
    return `<tr>
      <td>${escapeHtml(contact.display_name || '')}</td>
      <td>${escapeHtml(contact.zid || '')}</td>
      <td>${escapeHtml(contact.tag || '')}</td>
      <td>${escapeHtml(contact.sys_phone || '')}</td>
      <td>${escapeHtml(contact['_a/c'] || '')}</td>
      <td>${escapeHtml(contact._name || '')}</td>
      <td>${escapeHtml(formatTime(contact.updatedAt))}</td>
    </tr>`;
  }).join('');
}

function downloadXlsx(filename, headers, rows) {
  const wsData = rows.map(row => {
    const obj = {};
    headers.forEach(h => { obj[h] = row[h] || ''; });
    return obj;
  });
  const ws = XLSX.utils.json_to_sheet(wsData, { header: headers });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  XLSX.writeFile(wb, filename);
}

async function loadContacts() {
  const resp = await sendMessage({ type: 'GET_CONTACTS' });
  if (!resp.ok) throw new Error(resp.error || 'Không đọc được liên hệ.');
  renderContacts(resp.contacts || []);
}

statusCloseBtn.addEventListener('click', () => setStatus(''));

syncContactsBtn.addEventListener('click', async () => {
  try {
    setStatus('Đang đồng bộ liên hệ từ Zalo...');
    const resp = await sendMessage({ type: 'SYNC_CONTACTS' });
    if (!resp.ok) throw new Error(resp.error || 'Không đồng bộ được liên hệ.');
    renderContacts(resp.contacts || []);
    setStatus(`Đã đồng bộ ${resp.count || 0} liên hệ đang thấy trên Zalo.`);
  } catch (err) {
    setStatus(err?.message || 'Không đồng bộ được liên hệ.', true);
  }
});

reloadContactsBtn.addEventListener('click', async () => {
  try {
    await loadContacts();
    setStatus('Đã tải lại liên hệ.');
  } catch (err) {
    setStatus(err?.message || 'Không đọc được liên hệ.', true);
  }
});

exportContactsBtn.addEventListener('click', () => {
  const headers = ['display_name', 'zid', 'tag', 'sys_phone', '_a/c', '_name', 'updatedAt'];
  downloadXlsx('zalo-contacts.xlsx', headers, latestContacts);
  setStatus('Đã export XLSX liên hệ.');
});

clearContactsBtn.addEventListener('click', async () => {
  try {
    const resp = await sendMessage({ type: 'CLEAR_CONTACTS' });
    if (!resp.ok) throw new Error(resp.error || 'Không xóa được bảng liên hệ.');
    renderContacts(resp.contacts || []);
    setStatus('Đã xóa bảng liên hệ.');
  } catch (err) {
    setStatus(err?.message || 'Không xóa được bảng liên hệ.', true);
  }
});

loadContacts().catch((err) => {
  setStatus(err?.message || 'Không đọc được liên hệ.', true);
});
