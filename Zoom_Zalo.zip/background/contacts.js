// Contact mapping, preview mapping, and visible Zalo contact sync helpers.
async function saveZaloContact(result) {
  // Persist latest known zid by normalized phone number for later reuse/export.
  if (!result?.phone || !result?.zid) return;

  const data = await chrome.storage.local.get(['zaloContacts']);
  const zaloContacts = data.zaloContacts || {};
  zaloContacts[result.phone] = {
    zid: result.zid,
    name: result.name || '',
    phone: result.phone,
    sms: result.sms || '',
    addFriendState: result.addFriendState || '',
    updatedAt: Date.now()
  };
  await chrome.storage.local.set({ zaloContacts });
  await saveContactMapping(result);
}

/**
 * Tải bản đồ danh bạ từ chrome.storage.local và tự động chạy hàm dọn dẹp dữ liệu lỗi (nếu có).
 * Nếu có sự thay đổi trong quá trình dọn dẹp, lưu lại ngay lập tức vào storage.
 * 
 * @returns {Promise<Object>} Bản đồ danh bạ đã được chuẩn hóa và làm sạch
 */
async function loadContactMap() {
  const data = await storageGet([CONTACT_MAP_STORAGE_KEY]);
  const contactMap = data[CONTACT_MAP_STORAGE_KEY] || { byZid: {}, byName: {}, byPhone: {} };
  
  if (sanitizeContactMap(contactMap)) {
    await storageSet({ [CONTACT_MAP_STORAGE_KEY]: contactMap });
  }
  return contactMap;
}

/**
 * Lưu ánh xạ liên hệ Zalo (ZID, tên hiển thị, tag, sđt) vào cơ sở dữ liệu local.
 * Tự động trích xuất số điện thoại từ tên thô trước khi làm sạch để điền vào sys_phone nếu trống.
 * 
 * @param {Object} contact - Thông tin liên hệ cần lưu
 * @returns {Promise<void>}
 */
async function saveContactMapping(contact) {
  const zid = String(contact?.zid || '').trim();
  const rawName = contact?.display_name || contact?.name || '';
  const name = cleanZaloDisplayName(rawName);
  const phone = normalizePhone(contact?.phone);
  const phoneKey = normalizePhoneKey(phone);
  // Trích xuất số điện thoại từ tên thô trước khi làm sạch tên
  const namePhoneKey = extractPhoneKeyFromText(rawName);
  if (!zid || (!name && !phoneKey && !namePhoneKey)) return;

  const contactMap = await loadContactMap();
  const record = {
    zid,
    display_name: name,
    tag: contact?.tag || '',
    phone,
    // sys_phone ưu tiên số điện thoại chính thức, nếu không có thì lấy số trích xuất từ tên
    sys_phone: phoneKey || namePhoneKey || '',
    name_phone_normalized: namePhoneKey,
    '_a/c': contact?.['_a/c'] || parseDisplayNameParts(name)['_a/c'],
    _name: contact?._name || parseDisplayNameParts(name)._name,
    updatedAt: Date.now()
  };
  upsertContactRecord(contactMap, record);
  await storageSet({ [CONTACT_MAP_STORAGE_KEY]: contactMap });
}

/**
 * Lưu/Cập nhật hàng loạt ánh xạ liên hệ từ mảng các dòng dữ liệu.
 * Tự động trích xuất số điện thoại từ tên thô trước khi làm sạch để điền vào sys_phone nếu trống.
 * 
 * @param {Object[]} rows - Danh sách các dòng dữ liệu liên hệ (có thể từ file import hoặc từ UI)
 * @returns {Promise<void>}
 */
async function saveContactMappingsFromRows(rows) {
  if (!Array.isArray(rows) || !rows.length) return;

  const contactMap = await loadContactMap();
  let changed = false;

  rows.forEach((row) => {
    const values = row?.values || row || {};
    fillIntermediatePhoneColumns(values);
    const zid = String(values.zid || '').trim();
    const rawName = values.display_name || values.name || '';
    const name = cleanZaloDisplayName(rawName);
    const phone = normalizePhone(values.phone);
    const namePhoneKey = values._name_phone_normalized || extractPhoneKeyFromText(rawName);
    const phoneKey = values.sys_phone || normalizePhoneKey(phone) || namePhoneKey || '';
    if (!zid || (!name && !phoneKey && !namePhoneKey)) return;

    const record = {
      zid,
      display_name: name,
      tag: values.tag || '',
      phone,
      sys_phone: phoneKey,
      name_phone_normalized: namePhoneKey,
      '_a/c': values['_a/c'] || parseDisplayNameParts(name)['_a/c'],
      _name: values._name || parseDisplayNameParts(name)._name,
      updatedAt: Date.now()
    };
    upsertContactRecord(contactMap, record);
    changed = true;
  });

  if (changed) await storageSet({ [CONTACT_MAP_STORAGE_KEY]: contactMap });
}

async function findMappedContact(values) {
  fillIntermediatePhoneColumns(values);
  const nameToUse = values?.display_name || values?.name;
  const nameKey = normalizeLookupText(nameToUse);
  const phoneKey = values?.sys_phone || normalizePhoneKey(values?.phone);
  const namePhoneKey = values?._name_phone_normalized || extractPhoneKeyFromText(nameToUse);
  if (!nameKey && !phoneKey && !namePhoneKey) return null;

  const contactMap = await loadContactMap();
  const data = await storageGet(['zaloContacts']);
  return (nameKey && contactMap.byName?.[nameKey]) ||
    (phoneKey && contactMap.byPhone?.[phoneKey]) ||
    (namePhoneKey && contactMap.byPhone?.[namePhoneKey]) ||
    findLegacyContactByPhoneKey(data.zaloContacts, phoneKey) ||
    findLegacyContactByPhoneKey(data.zaloContacts, namePhoneKey) ||
    null;
}

async function mapRowsForPreview(rows) {
  // Resolve zid from contact map for rows that will be sent. Done rows are
  // skipped because phone-key lookup may match the wrong contact, producing
  // a zid that corrupts the contact database when saved later.
  const mappedRows = [];
  for (const row of rows || []) {
    const values = fillIntermediatePhoneColumns({ ...row });
    const isDone = String(values._status || '').toLowerCase() === 'done';
    const currentZid = String(values.zid || '').trim();
    if (!currentZid && !isDone) {
      const mapped = await findMappedContact(values);
      if (mapped?.zid) {
        values.zid = mapped.zid;
        if (!values.display_name && (mapped.display_name || mapped.name)) values.display_name = mapped.display_name || mapped.name;
        if (!values.phone && mapped.phone) values.phone = mapped.phone;
        fillIntermediatePhoneColumns(values);
      }
    }
    mappedRows.push(values);
  }
  return mappedRows;
}

async function buildPreviewPayload(payload) {
  const normalizedPayload = normalizeBatchColumns(payload?.headers || [], payload?.rows || []);
  const headers = normalizedPayload.headers.slice();
  if (!headers.includes('zid')) headers.push('zid');
  if (!headers.includes('send_at')) headers.push('send_at');
  if (!headers.includes(WAIT_REPLY_BATCH_COLUMN)) headers.push(WAIT_REPLY_BATCH_COLUMN);
  INTERMEDIATE_BATCH_COLUMNS.forEach((name) => {
    if (!headers.includes(name)) headers.push(name);
  });
  OUTPUT_BATCH_COLUMNS.forEach((name) => {
    if (!headers.includes(name)) headers.push(name);
  });
  return {
    mode: normalizeBatchMode(payload?.mode),
    headers,
    rows: await mapRowsForPreview(normalizedPayload.rows || []),
    importedAt: payload?.importedAt || Date.now()
  };
}

async function getStoredContacts() {
  const contactMap = await loadContactMap();
  const data = await storageGet(['zaloContacts']);
  return getContactRecords(contactMap, data.zaloContacts || {});
}

async function scrollSidebarAndCollect(tabId) {
  // Scrolls the Zalo sidebar conversation list from top to bottom in
  // viewport-height steps, collecting every rendered .msg-item at each
  // position. Zalo uses virtual scrolling so only a small window of items
  // exists in the DOM at any time. Returns a deduplicated array of contact
  // objects. Scrolls back to top when finished.
  const scriptResults = await scriptingExecuteScript({
    target: { tabId },
    func: async () => {
      const normalize = (text) => (text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      const stripTags = (text) => {
        let value = normalize(text).replace(/\s+Công việc(?:\s.*)?$/i, '').trim();
        const phones = [...value.matchAll(/(?:\+?84|0)?[\d\s().-]{8,}/g)];
        if (phones.length) {
          const last = phones[phones.length - 1];
          const end = last.index + last[0].length;
          const tail = value.slice(end).trim().toLowerCase();
          if (tail === 'công việc' || tail.startsWith('công việc ')) value = value.slice(0, end).trim();
        }
        return value;
      };

      const collectVisible = () => {
        return [...document.querySelectorAll('.msg-item[anim-data-id]')].map((el) => {
          const zid = el.getAttribute('anim-data-id');
          const rawTitle = (
            el.querySelector('.conv-item-title__name')?.innerText ||
            el.querySelector('[class*="title"]')?.innerText ||
            ''
          );
          const display_name = stripTags(rawTitle);
          const itemText = normalize(el.innerText || el.textContent || '');
          const tag = /\bCông việc\b/i.test(itemText) ? 'Công việc' : '';
          return { zid, display_name, name: display_name, tag, phone: '' };
        }).filter((item) => item.zid && item.display_name);
      };

      // Find the scrollable sidebar container (parent of .msg-item list)
      const firstItem = document.querySelector('.msg-item[anim-data-id]');
      if (!firstItem) return { contacts: collectVisible(), scrolled: false };

      let container = firstItem.parentElement;
      while (container && container !== document.body) {
        const style = window.getComputedStyle(container);
        if (container.scrollHeight > container.clientHeight + 10 &&
            (style.overflowY === 'auto' || style.overflowY === 'scroll')) {
          break;
        }
        container = container.parentElement;
      }
      if (!container || container === document.body) {
        return { contacts: collectVisible(), scrolled: false };
      }

      const seen = new Map();
      const addItems = (items) => {
        items.forEach((item) => {
          if (!seen.has(item.zid)) seen.set(item.zid, item);
        });
      };

      // Scroll to top first
      container.scrollTop = 0;
      await new Promise((r) => setTimeout(r, 300));
      addItems(collectVisible());

      const step = container.clientHeight;
      const maxScrolls = Math.ceil(container.scrollHeight / step) + 5;

      for (let i = 0; i < maxScrolls; i++) {
        const prevTop = container.scrollTop;
        container.scrollTop += step;
        await new Promise((r) => setTimeout(r, 350));

        addItems(collectVisible());

        // Stop if scroll position didn't change (reached bottom)
        if (Math.abs(container.scrollTop - prevTop) < 10) break;
      }

      // Scroll back to top
      container.scrollTop = 0;

      return { contacts: [...seen.values()], scrolled: true };
    }
  });
  const result = scriptResults[0]?.result;
  return {
    contacts: Array.isArray(result?.contacts) ? result.contacts : [],
    scrolled: !!result?.scrolled
  };
}

async function syncVisibleContacts() {
  // Scrolls through the entire Zalo sidebar to collect all contacts rendered
  // by the virtual list, then persists them into the contact map.
  const zaloTab = await ensureZaloTab();
  if (!zaloTab?.id) throw new Error('Khong mo duoc tab Zalo.');

  await tabsUpdate(zaloTab.id, { active: true });
  await waitForTabLoad(zaloTab.id);
  await sleep(500);

  const { contacts, scrolled } = await scrollSidebarAndCollect(zaloTab.id);

  // Also auto-update display_name for contacts whose stored name differs
  // from what Zalo currently shows.
  const contactMap = await loadContactMap();
  for (const item of contacts) {
    const stored = contactMap.byZid?.[item.zid];
    if (stored) {
      const domName = cleanZaloDisplayName(item.display_name || '');
      const storedName = cleanZaloDisplayName(stored.display_name || stored.name || '');
      if (domName && storedName && domName !== storedName) {
        item._nameChanged = true;
      }
    }
  }

  await saveContactMappingsFromRows(contacts);
  return {
    count: contacts.length,
    scrolled,
    contacts: await getStoredContacts()
  };
}

/**
 * Xóa sạch toàn bộ dữ liệu danh bạ liên hệ Zalo đã lưu trong bộ nhớ local storage.
 * @returns {Promise<Array>} Trả về mảng rỗng biểu thị danh bạ sau khi đã xóa sạch.
 */
async function clearContacts() {
  await storageRemove([CONTACT_MAP_STORAGE_KEY, 'zaloContacts']);
  return [];
}


