// Direct Zalo/Zoom automation actions used by scheduled and batch sends.
async function typeAndSendCurrentChat(tabId, message) {
  // Shared by both modes: current chat send and phone-search send.
  const inputPoint = await waitForValue(tabId, `(() => {
      const el = document.querySelector('#richInput');
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return r.width && r.height ? { x: r.x + r.width / 2, y: r.y + r.height / 2 } : null;
    })()`);
  if (!inputPoint) throw new Error('Khong tim thay o nhap Zalo.');

  await clickPoint(tabId, inputPoint);
  await sleep(120);
  await clearFocusedText(tabId);
  await sleep(150);
  await insertText(tabId, message);
  await sleep(1000);

  const typed = await evaluateValue(tabId, `(() => document.querySelector('#richInput')?.innerText || '')()`);
  const normalizeString = (str) => (str || '').replace(/[\\s\\u200B-\\u200D\\uFEFF]+/g, '').trim();
  if (normalizeString(typed) !== normalizeString(message)) {
    console.error('Validation mismatch. Expected:', message, '\\nActual:', typed);
    throw new Error('Noi dung trong o nhap Zalo khong dung.');
  }

  const sendPoint = await evaluateValue(tabId, `(() => {
    const btn = document.querySelector('.send-msg-btn') || document.querySelector('[data-translate-title="STR_SEND"]');
    if (!btn) return null;
    const r = btn.getBoundingClientRect();
    return r.width && r.height ? { x: r.x + r.width / 2, y: r.y + r.height / 2 } : null;
  })()`);
  if (!sendPoint) throw new Error('Khong tim thay nut Send cua Zalo.');

  await clickPoint(tabId, sendPoint);
  await sleep(800);
}

async function typeAndSendZalo(tabId, message) {
  await attachDebugger(tabId);
  try {
    await typeAndSendCurrentChat(tabId, message);
  } finally {
    await detachDebugger(tabId);
  }
}

async function findExactVisibleTextPoint(tabId, text, minX = 0) {
  return evaluateValue(tabId, `(() => {
    const target = ${JSON.stringify(text)};
    const minX = ${JSON.stringify(minX)};
    const nodes = [...document.querySelectorAll('button, .z--btn--v2, [role="button"], .z-banner, div')];
    const matches = nodes.filter((el) => {
      const r = el.getBoundingClientRect();
      const current = (el.innerText || el.textContent || '').trim().replace(/\\s+/g, ' ');
      return r.width && r.height && r.x >= minX && current === target;
    });
    const el = matches[matches.length - 1] || null;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.x + r.width / 2, y: r.y + r.height / 2, text: target };
  })()`);
}

async function clickAddFriendIfAvailable(tabId) {
  // Zalo's banner button opens the profile panel. The actual friend request is
  // sent only after clicking the "Kết bạn" button inside that panel.
  const bannerPoint = await findExactVisibleTextPoint(tabId, 'Gửi kết bạn', 400);
  if (!bannerPoint) return 'not_available';

  await clickPoint(tabId, bannerPoint);
  await sleep(1200);

  const panelPoint = await findExactVisibleTextPoint(tabId, 'Kết bạn', 400);
  if (!panelPoint) return 'opened_panel_without_button';

  await clickPoint(tabId, panelPoint);
  await sleep(2500);

  const successText = await evaluateValue(tabId, `(() => document.body.innerText.includes('Gửi yêu cầu kết bạn thành công'))()`);
  return successText ? 'sent' : 'clicked';
}

async function findConversationByNameOrSms(tabId, name, sms) {
  // After sending SMS to a searched phone number, Zalo creates/moves a sidebar
  // conversation item. Its anim-data-id is the zid we persist.
  return waitForValue(tabId, `(() => {
    const normalize = (text) => (text || '').replace(/\\u00a0/g, ' ').replace(/\\s+/g, ' ').trim();
    const targetName = normalize(${JSON.stringify(name)});
    const targetSms = normalize(${JSON.stringify(sms)});
    const items = [...document.querySelectorAll('.msg-item[anim-data-id]')].map((el) => {
      const itemName = normalize(el.querySelector('.conv-item-title__name')?.innerText || '');
      const preview = normalize(el.querySelector('.conv-item-body, .z-conv-message')?.innerText || '');
      return {
        zid: el.getAttribute('anim-data-id'),
        name: itemName,
        preview
      };
    }).filter((item) => item.zid && item.name);

    return items.find((item) => item.name === targetName) ||
      items.find((item) => item.preview === 'Bạn: ' + targetSms) ||
      null;
  })()`, 5000, 250);
}

async function searchPhoneFirstResult(tabId, phone) {
  const normalizedPhone = normalizePhone(phone);
  if (!normalizedPhone) throw new Error('Thieu phone de tim zid.');

  await tabsUpdate(tabId, { active: true });
  await sleep(300);

  const searchPoint = await evaluateValue(tabId, `(() => {
    const el = document.querySelector('#contact-search-input');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return r.width && r.height ? { x: r.x + r.width / 2, y: r.y + r.height / 2 } : null;
  })()`);
  if (!searchPoint) throw new Error('Khong tim thay o search Zalo.');

  await clickPoint(tabId, searchPoint);
  await sleep(150);
  await clearFocusedText(tabId);
  await sleep(150);
  await insertText(tabId, normalizedPhone);

  const searchValue = await waitForValue(
    tabId,
    `(() => document.querySelector('#contact-search-input')?.value === ${JSON.stringify(normalizedPhone)} ? true : null)()`,
    3000,
    100
  );
  if (!searchValue) throw new Error('Khong nhap duoc so dien thoai vao o search.');

  const firstResult = await waitForValue(tabId, `(() => {
    const phone = ${JSON.stringify(normalizedPhone)};
    const list = document.querySelector('#searchResultList');
    if (!list) return null;
    const items = [...list.querySelectorAll('[id^="friend-item-"], .conv-item')].filter((el) => {
      const text = (el.innerText || el.textContent || '').replace(/\\s+/g, ' ');
      const r = el.getBoundingClientRect();
      const normalizedText = text.replace(/[^\\d+]/g, '');
      return r.width && r.height && normalizedText.includes(phone);
    });
    const el = items[0];
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const text = (el.innerText || el.textContent || '').trim().replace(/\\s+/g, ' ');
    return {
      x: r.x + r.width / 2,
      y: r.y + r.height / 2,
      name: text.split(' Số điện thoại:')[0] || text,
      text
    };
  })()`, 12000, 250);
  if (!firstResult) throw new Error(`Khong tim duoc ket qua dau cho so ${normalizedPhone}.`);

  await clickPoint(tabId, firstResult);
  await sleep(800);

  return {
    phone: normalizedPhone,
    zid: '',
    name: firstResult.name,
    clicked: true
  };
}

async function searchPhoneSendSmsAndAddFriend(tabId, phone, sms) {
  // Full phone flow: search phone -> click first result -> send SMS -> read zid
  // -> try add friend if Zalo shows the button.
  await tabsUpdate(tabId, { active: true });
  await sleep(300);
  await attachDebugger(tabId);
  try {
    const searchPoint = await evaluateValue(tabId, `(() => {
      const el = document.querySelector('#contact-search-input');
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return r.width && r.height ? { x: r.x + r.width / 2, y: r.y + r.height / 2 } : null;
    })()`);
    if (!searchPoint) throw new Error('Khong tim thay o search Zalo.');

    await clickPoint(tabId, searchPoint);
    await sleep(150);
    await clearFocusedText(tabId);
    await sleep(150);
    await insertText(tabId, phone);

    const searchValue = await waitForValue(
      tabId,
      `(() => document.querySelector('#contact-search-input')?.value === ${JSON.stringify(phone)} ? true : null)()`,
      3000,
      100
    );
    if (!searchValue) throw new Error('Khong nhap duoc so dien thoai vao o search.');

    const firstResult = await waitForValue(tabId, `(() => {
      const phone = ${JSON.stringify(phone)};
      const list = document.querySelector('#searchResultList');
      if (!list) return null;
      const items = [...list.querySelectorAll('[id^="friend-item-"], .conv-item')].filter((el) => {
        const text = (el.innerText || el.textContent || '').replace(/\\s+/g, ' ');
        const r = el.getBoundingClientRect();
        return r.width && r.height && text.includes(phone);
      });
      const el = items[0];
      if (!el) return null;
      const r = el.getBoundingClientRect();
      const text = (el.innerText || el.textContent || '').trim().replace(/\\s+/g, ' ');
      return {
        x: r.x + r.width / 2,
        y: r.y + r.height / 2,
        name: text.split(' Số điện thoại:')[0] || text,
        text
      };
    })()`, 12000, 250);
    if (!firstResult) throw new Error(`Khong tim duoc ket qua dau cho so ${phone}.`);

    await clickPoint(tabId, firstResult);
    
    // Đợi cho cuộc hội thoại khớp với kết quả tìm kiếm được mở chính thức
    const opened = await waitForValue(tabId, `(() => {
      const headerEl = document.querySelector('#header .header-title, #header .threadChat__title');
      const headerName = (headerEl?.innerText || headerEl?.textContent || '').trim().toLowerCase();
      const expectedName = ${JSON.stringify(firstResult.name)}.trim().toLowerCase();
      return headerName && (headerName.includes(expectedName) || expectedName.includes(headerName)) ? true : null;
    })()`, 12000, 250);
    if (!opened) throw new Error('Cuoc hoi thoai tu search khong mo duoc dung ten.');

    await typeAndSendCurrentChat(tabId, sms);
    await sleep(2700);
    const conversation = await findConversationByNameOrSms(tabId, firstResult.name, sms);
    if (!conversation?.zid) throw new Error('Da gui SMS nhung khong lay duoc zid cua doan chat.');
    const addFriendState = await clickAddFriendIfAvailable(tabId);
    return {
      phone,
      sms,
      zid: conversation.zid,
      name: conversation.name || firstResult.name,
      addFriendState
    };
  } finally {
    await detachDebugger(tabId);
  }
}

async function runTask() {
  const data = await chrome.storage.local.get(['schedule']);
  const schedule = data.schedule || { isScheduled: false, runAt: 0 };
  if (!schedule.isScheduled) return;
  if (!schedule.message) throw new Error('Chua co noi dung tin nhan.');

  const zoomTab = await findFirstTabByUrl([/\.zoom\.us\//i]);
  if (zoomTab?.id) {
    await chrome.tabs.update(zoomTab.id, { active: true });
    await sleep(300);
    await sendToTab(zoomTab.id, { type: 'ZOOM_END' });
    await sleep(1800);
  }

  const zaloTab = await findFirstTabByUrl([/chat\.zalo\.me/i]);
  if (!zaloTab?.id) throw new Error('Khong tim thay tab Zalo.');

  await chrome.tabs.update(zaloTab.id, { active: true });
  await sleep(500);
  if (schedule.phone) {
    return searchPhoneSendSmsAndAddFriend(zaloTab.id, schedule.phone, schedule.message);
  }

  await typeAndSendZalo(zaloTab.id, schedule.message);
  return {
    phone: '',
    sms: schedule.message,
    zid: '',
    name: '',
    addFriendState: 'skipped_no_phone'
  };
}
