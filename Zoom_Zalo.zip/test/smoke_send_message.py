import sys
import traceback

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

sys.path.append(r"D:\Source_Code\Python")
sys.path.append(r"D:\Source_Code\Python\pyhuy")

from pyhuy.xlogin_pw import XProfile


EXT_ID = "pddnflnmoiamjjkfeaimlhejggfpndoa"
SEND_MESSAGE_URL = f"chrome-extension://{EXT_ID}/batch-page/send_message.html"
CONTACTS_URL = f"chrome-extension://{EXT_ID}/contacts-page/contacts.html"


def dump_send_message(page, label):
    data = page.evaluate(
        """(label) => {
            const rows = [...document.querySelectorAll('#tableBody tr')].map((tr) =>
                [...tr.querySelectorAll('td')].map((td) => td.innerText)
            );
            const headers = [...document.querySelectorAll('#tableHead th')].map((th) => th.innerText);
            return {
                label,
                url: location.href,
                title: document.title,
                summary: document.querySelector('#summary')?.innerText || '',
                statusDisplay: getComputedStyle(document.querySelector('#status')).display,
                status: document.querySelector('#statusText')?.innerText || '',
                emptyDisplay: getComputedStyle(document.querySelector('#emptyState')).display,
                tableDisplay: getComputedStyle(document.querySelector('#tableWrap')).display,
                headers,
                rows,
                headerBottom: document.querySelector('#tableHead')?.getBoundingClientRect().bottom || 0,
                firstRowTop: document.querySelector('#tableBody tr')?.getBoundingClientRect().top || 0,
                startDisabled: document.querySelector('#startBtn')?.disabled,
                exportDisabled: document.querySelector('#exportBtn')?.disabled,
            };
        }""",
        label,
    )
    print(f"\n=== {label} ===")
    for key, value in data.items():
        print(f"{key}: {value}")
    return data


def main():
    x_driver = XProfile("AI_tool").connect_browser()
    if not x_driver:
        raise RuntimeError("Không kết nối được profile AI_tool")

    page = x_driver.page
    page.goto(SEND_MESSAGE_URL, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(1000)
    data = dump_send_message(page, "send message readonly")

    if data["title"] != "Gửi tin nhắn":
        raise AssertionError(f"Send message page title mismatch: {data['title']!r}")
    if data["tableDisplay"] != "none" and data["firstRowTop"] and data["firstRowTop"] < data["headerBottom"]:
        raise AssertionError("First data row is above/overlapping the header")

    page.goto(CONTACTS_URL, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(500)
    contacts = page.evaluate(
        """() => ({
            title: document.title,
            summary: document.querySelector('#summary')?.innerText || '',
            rows: document.querySelectorAll('#contactsBody tr').length,
            status: document.querySelector('#statusText')?.innerText || '',
        })"""
    )
    print("\n=== contacts page ===")
    print(contacts)
    if contacts["title"] != "Liên hệ":
        raise AssertionError(f"Contacts page title mismatch: {contacts['title']!r}")

    print("\nSMOKE OK")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
