# -*- coding: utf-8 -*-
import sys
import traceback

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

sys.path.append(r"D:\Source_Code\Python")
sys.path.append(r"D:\Source_Code\Python\pyhuy")

from pyhuy.xlogin_pw import XProfile

EXT_ID = "pddnflnmoiamjjkfeaimlhejggfpndoa"
MAIN_PAGE_URL = f"chrome-extension://{EXT_ID}/main-page/main.html"


def dump_main_page(page, label):
    """
    Trích xuất và in ra thông số hiện tại của giao diện main-page phục vụ phân tích.
    """
    data = page.evaluate(
        """(label) => {
            const campaignVisible = !document.getElementById('campaignTab').classList.contains('hidden');
            const contactsVisible = !document.getElementById('contactsTab').classList.contains('hidden');
            
            const queueRows = [...document.querySelectorAll('#queueTableBody tr')].map((tr) =>
                [...tr.querySelectorAll('td')].map((td) => td.innerText)
            );
            
            const contactRows = [...document.querySelectorAll('#contactsDatabaseBody tr')].map((tr) =>
                [...tr.querySelectorAll('td')].map((td) => td.innerText)
            );

            return {
                label,
                url: location.href,
                title: document.title,
                campaignVisible,
                contactsVisible,
                pendingVal: document.getElementById('statsPending')?.innerText || '',
                watchingVal: document.getElementById('statsWatching')?.innerText || '',
                doneVal: document.getElementById('statsDone')?.innerText || '',
                errorsVal: document.getElementById('statsErrors')?.innerText || '',
                queueRowCount: queueRows.length,
                contactRowCount: contactRows.length,
            };
        }""",
        label,
    )
    print(f"\n=== {label} ===")
    for key, value in data.items():
        print(f"{key}: {value}")
    return data


def main():
    print("Khởi chạy smoke test cho giao diện main-page...")
    x_driver = XProfile("AI_tool").connect_browser()
    if not x_driver:
        raise RuntimeError("Không kết nối được profile AI_tool")

    page = x_driver.page
    
    # Đăng ký bắt lỗi từ Console và Page Error
    page.on("console", lambda msg: print(f"CONSOLE: [{msg.type}] {msg.text}"))
    page.on("pageerror", lambda err: print(f"PAGE ERROR: {err}"))

    print(f"Điều hướng tới: {MAIN_PAGE_URL}")
    page.goto(MAIN_PAGE_URL, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(1500)
    data = dump_main_page(page, "Trạng thái tải ban đầu (Tab Chiến dịch mặc định)")
    if "Z-Campaigner" not in data["title"]:
        raise AssertionError(f"Tiêu đề trang không khớp mong muốn: {data['title']!r}")
    if not data["campaignVisible"]:
        raise AssertionError("Tab Chiến dịch phải hiển thị mặc định")
    if data["contactsVisible"]:
        raise AssertionError("Tab Danh bạ phải ẩn khi khởi tạo")

    # 2. Kiểm tra thao tác chuyển Tab
    print("\nClick chọn tab Danh bạ...")
    page.click("#tabContactsBtn")
    page.wait_for_timeout(500)
    
    data_tab2 = dump_main_page(page, "Sau khi chuyển sang Tab Danh bạ")
    if data_tab2["campaignVisible"]:
        raise AssertionError("Tab Chiến dịch phải ẩn sau khi chuyển tab")
    if not data_tab2["contactsVisible"]:
        raise AssertionError("Tab Danh bạ phải hiển thị sau khi chuyển tab")

    # Quay lại tab Chiến dịch
    print("\nQuay lại tab Chiến dịch...")
    page.click("#tabCampaignBtn")
    page.wait_for_timeout(500)
    
    data_tab1 = dump_main_page(page, "Quay lại Tab Chiến dịch")
    if not data_tab1["campaignVisible"]:
        raise AssertionError("Tab Chiến dịch phải hiển thị lại")
    if data_tab1["contactsVisible"]:
        raise AssertionError("Tab Danh bạ phải ẩn lại")

    print("\n=== SMOKE TEST MAIN PAGE THÀNH CÔNG ===")


if __name__ == "__main__":
    try:
      main()
    except Exception:
      traceback.print_exc()
      sys.exit(1)
