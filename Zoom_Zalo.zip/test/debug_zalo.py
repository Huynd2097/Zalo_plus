import json
import asyncio
import websockets
import urllib.request

async def reload_extension():
    req = urllib.request.urlopen("http://127.0.0.1:9193/json")
    tabs = json.loads(req.read().decode('utf-8'))
    
    sw_ws = None
    for t in tabs:
        if t.get("type") == "service_worker" and "Zoom_Zalo" in t.get("url", "") or "background.js" in t.get("url", ""):
            sw_ws = t.get("webSocketDebuggerUrl")
            break

    if not sw_ws:
        return

    async with websockets.connect(sw_ws) as ws:
        req = {
            "id": 1,
            "method": "Runtime.evaluate",
            "params": {
                "expression": "chrome.runtime.reload()",
                "returnByValue": True
            }
        }
        await ws.send(json.dumps(req))
        resp = await ws.recv()
        print("Reloaded!")

asyncio.run(reload_extension())
