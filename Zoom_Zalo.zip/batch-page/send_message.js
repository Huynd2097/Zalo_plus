const summaryEl = document.getElementById('summary');
const statusEl = document.getElementById('status');
const statusTextEl = document.getElementById('statusText');
const statusCloseBtn = document.getElementById('statusCloseBtn');
const headEl = document.getElementById('tableHead');
const bodyEl = document.getElementById('tableBody');
const emptyStateEl = document.getElementById('emptyState');
const tableWrapEl = document.getElementById('tableWrap');
const templateBtn = document.getElementById('templateBtn');
const importBtn = document.getElementById('importBtn');
const csvFileInput = document.getElementById('csvFile');
const startBtn = document.getElementById('startBtn');
const exportBtn = document.getElementById('exportBtn');
const clearBtn = document.getElementById('clearBtn');
const stopBtn = document.getElementById('stopBtn');
const endBtn = document.getElementById('endBtn');
const searchInput = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');

const TEMPLATE_HEADERS = ['name', 'phone', 'send_at', 'wait_reply', 'message', 'zid'];
const HIDDEN_TABLE_HEADERS = ['sys_phone'];
const STATE_OPTIONS = ['pending', 'wait_reply', 'done'];

const TEMPLATE_NOTE_ROW = {
  name: 'Không bắt buộc. Nhập đúng tên Zalo để map zid đã lưu; tên có thể chứa SĐT để hệ thống tách ra match.',
  zid: 'Không bắt buộc nếu có name hoặc phone. Nếu biết zid thì nhập để gửi trực tiếp và lưu mapping.',
  phone: 'Không bắt buộc. Chấp nhận 987654321, 0987654321, 84987654321 hoặc +84987654321; phone_normalized lưu dạng 987654321.',
  send_at: 'Không bắt buộc. Thời gian hẹn gửi, ví dụ 2026-06-02 14:30. Bỏ trống thì gửi ngay.',
  wait_reply: 'Không bắt buộc. Nhập x nếu cần chờ và lấy phản hồi sau khi gửi.',
  message: 'Bắt buộc. Nội dung tin nhắn cần gửi.'
};

let latestQueue = null;
let latestWorkerState = null;
let pollTimer = null;
let dismissedStatusText = '';
let editingCell = null;
let stateSelectActive = false;

function applyModeUi() {
  document.title = 'Gửi tin nhắn';
  const titleEl = document.querySelector('h1');
  if (titleEl) titleEl.textContent = 'Gửi tin nhắn';
}

/**
 * Hiển thị thông báo trạng thái trên thanh thông báo.
 * @param {string} text - Nội dung thông báo
 * @param {boolean} [isError=false] - Trạng thái lỗi hay thông báo thường
 * @param {Object} [options={}] - Các cấu hình mở rộng
 */
function setStatus(text, isError = false, options = {}) {
  const message = String(text || '').trim();
  if (options.fromBatch && message && message === dismissedStatusText) return;
  if (!options.fromBatch && message) dismissedStatusText = '';
  statusTextEl.textContent = message;
  statusEl.classList.toggle('status-error', Boolean(isError));
  statusEl.style.display = message ? 'flex' : 'none';
}

function clearStatus() {
  dismissedStatusText = statusTextEl.textContent.trim();
  setStatus('');
}

/**
 * Gửi message đến background service worker.
 * @param {Object} message - Đối tượng thông điệp
 * @returns {Promise<Object>} Phản hồi từ background
 */
function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(resp || { ok: false, error: 'Không nhận được phản hồi.' });
    });
  });
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const buffer = reader.result;
        try {
          resolve(new TextDecoder('utf-8', { fatal: true }).decode(buffer));
          return;
        } catch (_utf8Err) {
          resolve(new TextDecoder('windows-1258').decode(buffer));
          return;
        }
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(reader.error || new Error('Không đọc được file CSV.'));
    reader.readAsArrayBuffer(file);
  });
}

function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function stripZaloTags(text) {
  let value = String(text ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().replace(/\s+Công việc(?:\s.*)?$/i, '').trim();
  const phones = [...value.matchAll(/(?:\+?84|0)?[\d\s().-]{8,}/g)];
  if (phones.length) {
    const last = phones[phones.length - 1];
    const end = last.index + last[0].length;
    const tail = value.slice(end).trim().toLowerCase();
    if (tail === 'công việc' || tail.startsWith('công việc ')) value = value.slice(0, end).trim();
  }
  return value;
}

function buildExportRows(queue) {
  return Object.values(queue.byId).map((row) => {
    const values = { ...row.values };
    values.replies = (row.replies || []).slice(0, 5).join('\n');
    values.error = row.error || '';
    values.status = row.status || 'pending';
    return values;
  });
}

function rowHasWaitReply(row) {
  return String(row?.values?.wait_reply ?? row?.wait_reply ?? '').trim().toLowerCase() === 'x';
}

function orderHeaders(headers, options = {}) {
  const hidden = options.hidden || [];
  const next = [];
  (headers || []).forEach((header) => {
    if (!header || hidden.includes(header) || header === 'zid' || header === 'wait_reply') return;
    next.push(header);
  });
  if (!hidden.includes('wait_reply')) next.push('wait_reply');
  if (!hidden.includes('zid')) next.push('zid');
  return next;
}

function countRespondedRows(rows) {
  return rows.filter((row) => (row.replies || []).length > 0).length;
}

function updateSummary(queue, state) {
  const rows = Object.values(queue?.byId || {});
  if (!rows.length) {
    summaryEl.textContent = 'Chưa có hàng chờ';
    return;
  }

  const doneCount = rows.filter((row) => row.status === 'done').length;
  const pendingCount = rows.filter((row) => ['pending', 'sending'].includes(row.status)).length;
  const waitReplyCount = rows.filter((row) => row.status === 'wait_reply').length;
  const responded = countRespondedRows(rows);
  const errors = rows.filter((row) => row.status === 'error' || row.error).length;

  let phaseText = 'Sẵn sàng';
  if (state?.running) {
    if (state.phase === 'paused') phaseText = 'Đã tạm dừng';
    else if (state.phase === 'sending') phaseText = 'Đang gửi tin';
    else if (state.phase === 'polling') phaseText = 'Đang lấy phản hồi';
  } else if (doneCount === rows.length) {
    phaseText = 'Đã hoàn tất';
  }

  summaryEl.innerHTML = `
    <span class="summary-pill summary-phase">${escapeHtml(phaseText)}</span>
    <span class="summary-pill summary-progress">Chờ gửi: ${pendingCount} | Chờ reply: ${waitReplyCount} | Xong: ${doneCount}/${rows.length}</span>
    <span class="summary-pill summary-replies">${responded} người phản hồi</span>
    <span class="summary-pill summary-errors${errors ? '' : ' is-zero'}">${errors} lỗi</span>
  `;
}

function isTemplateNoteRow(row) {
  return TEMPLATE_HEADERS.every((header) => String(row?.[header] || '').trim() === TEMPLATE_NOTE_ROW[header]);
}

function normalizeVietnameseText(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function isTemplateMessageNote(value) {
  const text = normalizeVietnameseText(value);
  return text.includes('bat buoc') && text.includes('noi dung') && text.includes('tin nhan') && text.includes('can gui');
}

function hasTemplateNoteCell(row) {
  return TEMPLATE_HEADERS.some((header) => {
    const value = String(row?.[header] || '').trim();
    return value && (value === TEMPLATE_NOTE_ROW[header] || (header === 'message' && isTemplateMessageNote(value)));
  });
}

function normalizeHeaderName(header) {
  const value = String(header || '').replace(/^\ufeff/, '').replace(/\u00a0/g, ' ').trim();
  const lower = value.toLowerCase();
  const known = {
    name: 'name',
    zid: 'zid',
    phone: 'phone',
    send_at: 'send_at',
    wait_reply: 'wait_reply',
    message: 'message',
    msg: 'message',
    content: 'message',
    text: 'message',
    body: 'message',
    'noi dung': 'message',
    'nội dung': 'message',
    'tin nhan': 'message',
    'tin nhắn': 'message',
    display_name: 'display_name',
    tag: 'tag',
    sys_phone: 'sys_phone',
    replies: 'replies',
    error: 'error'
  };
  return known[lower] || value;
}

function normalizeParsedColumns(parsed) {
  const headers = [];
  const headerMap = new Map();

  (parsed.headers || []).forEach((header) => {
    const normalized = normalizeHeaderName(header);
    if (!normalized) return;
    if (!headers.includes(normalized)) headers.push(normalized);
    headerMap.set(header, normalized);
  });

  const rows = (parsed.rows || []).map((row) => {
    const next = {};
    Object.entries(row || {}).forEach(([key, value]) => {
      const normalized = headerMap.get(key) || normalizeHeaderName(key);
      if (!normalized) return;
      next[normalized] = value;
    });
    return next;
  });

  return { headers, rows };
}

function hasData(row) {
  return Object.values(row || {}).some((value) => String(value || '').trim() !== '');
}

function validateRowsHaveMessage(rows) {
  const missingRows = [];
  rows.forEach((row, index) => {
    if (!String(row?.message || '').trim()) missingRows.push(index + 1);
  });
  if (missingRows.length) {
    const shown = missingRows.slice(0, 10).join(', ');
    const more = missingRows.length > 10 ? ', ...' : '';
    throw new Error(`Cac dong thieu message: ${shown}${more}. Hay nhap noi dung that vao cot message, khong de nguyen dong huong dan cua template.`);
  }
}

function getRowZid(row) {
  return String(row?.zid || '').trim();
}

function chooseImportConflictAction(count) {
  if (!count) return 'append';
  const replace = confirm(`Có ${count} dòng trùng ZID/SĐT với bảng hiện tại.\n\nBấm OK để ghi đè (thay thế) dòng cũ.\nBấm Cancel để chọn bỏ qua trùng hoặc hủy.`);
  if (replace) return 'replace';
  const skip = confirm('Bấm OK để chỉ thêm các dòng mới (bỏ qua dòng trùng ZID).\nBấm Cancel để hủy bỏ hoàn toàn.');
  return skip ? 'skip' : 'cancel';
}

function mergeImportedRows(existingRows, importedRows) {
  const zidToIndex = new Map();
  existingRows.forEach((row, index) => {
    const zid = getRowZid(row);
    if (zid) zidToIndex.set(zid, index);
  });

  const conflictCount = importedRows.filter((row) => {
    const zid = getRowZid(row);
    return zid && zidToIndex.has(zid);
  }).length;
  
  const action = chooseImportConflictAction(conflictCount);
  if (action === 'cancel') return null;

  const merged = existingRows.map((row) => ({ ...row }));
  importedRows.forEach((row) => {
    const zid = getRowZid(row);
    const index = zid ? zidToIndex.get(zid) : undefined;
    if (Number.isInteger(index)) {
      if (action === 'replace') merged[index] = { ...row };
      return;
    }
    if (zid) zidToIndex.set(zid, merged.length);
    merged.push({ ...row });
  });
  return merged;
}

function downloadXlsx(filename, headers, rows) {
  const wsData = rows.map(row => {
    const obj = {};
    headers.forEach(h => { obj[h] = row[h] || ''; });
    return obj;
  });
  const ws = XLSX.utils.json_to_sheet(wsData, { header: headers });
  Object.keys(ws).forEach((addr) => {
    if (addr[0] !== '!' && ws[addr]?.v && String(ws[addr].v).includes('\n')) {
      ws[addr].s = { alignment: { wrapText: true, vertical: 'top' } };
    }
  });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  XLSX.writeFile(wb, filename);
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('Không đọc được file.'));
    reader.readAsArrayBuffer(file);
  });
}

function buildImportConfirmText(newRows, totalImported) {
  const sample = newRows.slice(0, 5).map((row, index) => {
    const name = String(row.name || '').trim() || '(không có tên)';
    const zid = String(row.zid || '').trim() || '(thiếu zid)';
    const phone = String(row.phone || '').trim();
    const message = String(row.message || '').trim();
    return `${index + 1}. ${name}${phone ? ` | ${phone}` : ''} | zid=${zid} | message="${message}"`;
  }).join('\n');
  const more = newRows.length > 5 ? `\n... và ${newRows.length - 5} dòng khác` : '';
  return `Bạn có chắc chắn muốn thêm ${totalImported} dòng này vào hàng chờ không?\n\nXem trước 5 dòng đầu:\n${sample}${more}`;
}

function render(queue, state) {
  latestQueue = queue || { byId: {}, headers: [] };
  latestWorkerState = state || { running: false, phase: 'idle', currentRowId: null, message: '' };

  const rows = Object.values(latestQueue.byId).sort((a, b) => a.createdAt - b.createdAt);
  const hasRows = rows.length > 0;

  updateSummary(latestQueue, latestWorkerState);

  // Hiển thị thông báo trạng thái
  if (latestWorkerState.message) {
    setStatus(latestWorkerState.message, false, { fromBatch: true });
  } else if (latestWorkerState.currentRowId && latestQueue.byId[latestWorkerState.currentRowId]) {
    const row = latestQueue.byId[latestWorkerState.currentRowId];
    setStatus(`Đang gửi tin cho: ${row.values?.name || row.values?.display_name || row.id}`);
  } else {
    setStatus('');
  }

  emptyStateEl.style.display = hasRows ? 'none' : 'block';
  tableWrapEl.style.display = hasRows ? 'block' : 'none';
  exportBtn.disabled = !hasRows;

  // Điều khiển các nút trạng thái worker
  const running = latestWorkerState.running;
  const phase = latestWorkerState.phase;

  if (!running) {
    startBtn.style.display = '';
    startBtn.disabled = !hasRows;
    startBtn.textContent = 'Bắt đầu';
    
    stopBtn.style.display = 'none';
    endBtn.style.display = 'none';
  } else if (phase === 'paused') {
    startBtn.style.display = '';
    startBtn.disabled = false;
    startBtn.textContent = 'Tiếp tục';
    
    stopBtn.style.display = 'none';
    endBtn.style.display = '';
    endBtn.disabled = false;
  } else {
    startBtn.style.display = 'none';
    
    stopBtn.style.display = '';
    stopBtn.disabled = false;
    stopBtn.textContent = 'Tạm dừng';
    
    endBtn.style.display = '';
    endBtn.disabled = false;
  }

  if (!hasRows) {
    headEl.innerHTML = '';
    bodyEl.innerHTML = '';
    return;
  }

  // Lọc theo trạng thái và tìm kiếm
  let displayRows = rows;
  const statusFilterVal = statusFilter?.value || '';
  if (statusFilterVal) {
    displayRows = displayRows.filter((row) => row.status === statusFilterVal);
  }

  const query = (searchInput?.value || '').trim().toLowerCase();
  if (query) {
    displayRows = displayRows.filter((row) => {
      const valuesStr = Object.values(row.values || {}).join(' ').toLowerCase();
      const statusStr = String(row.status || '').toLowerCase();
      const repliesStr = (row.replies || []).join(' ').toLowerCase();
      const errStr = String(row.error || '').toLowerCase();
      return valuesStr.includes(query) || statusStr.includes(query) || repliesStr.includes(query) || errStr.includes(query);
    });
  }

  const visibleHeaders = orderHeaders(latestQueue.headers || [], { hidden: HIDDEN_TABLE_HEADERS });
  const displayHeaders = ['_state', ...visibleHeaders];

  headEl.innerHTML = `<tr>${displayHeaders.map((header) => `<th>${header === '_state' ? 'state' : escapeHtml(header)}</th>`).join('')}</tr>`;
  
  bodyEl.innerHTML = displayRows.map((row) => {
    const rowId = row.id;
    const stateValue = row.status || 'pending';
    const stateClass = `state state-${escapeHtml(stateValue)}`;
    const options = STATE_OPTIONS.map((status) => {
      const selected = status === stateValue ? ' selected' : '';
      return `<option value="${escapeHtml(status)}"${selected}>${escapeHtml(status)}</option>`;
    }).join('');

    const stateCell = `<td class="${stateClass}"><select class="state-select" data-row-id="${rowId}" data-header="_state">${options}</select></td>`;
    
    const cells = visibleHeaders.map((header) => {
      let value = row.values?.[header] ?? '';
      if (header === 'display_name' || header === 'name') value = stripZaloTags(value);
      if (header === 'replies') value = (row.replies || []).slice(0, 5).join('\n');
      if (header === 'error') value = row.error || '';
      if (header === 'wait_reply') {
        const checked = String(value).trim().toLowerCase() === 'x' ? ' checked' : '';
        return `<td><input type="checkbox" class="wait-reply-check" data-row-id="${rowId}" data-header="wait_reply"${checked}></td>`;
      }
      const editable = !['replies', 'error'].includes(header);
      const attrs = editable
        ? ` contenteditable="true" data-row-id="${rowId}" data-header="${escapeHtml(header)}" spellcheck="false"`
        : '';
      return `<td${attrs}>${escapeHtml(value)}</td>`;
    });

    return `<tr data-row-id="${rowId}">${stateCell}${cells.join('')}</tr>`;
  }).join('');
}

async function pollStatus() {
  const resp = await sendMessage({ type: 'GET_QUEUE' });
  if (resp.ok && resp.queue && resp.state) {
    latestQueue = resp.queue;
    latestWorkerState = resp.state;

    const activeStateSelect = document.activeElement?.closest?.('select.state-select');
    if (editingCell || stateSelectActive || activeStateSelect || window.getSelection().toString().trim().length > 0) {
      updateSummary(latestQueue, latestWorkerState);
      if (latestWorkerState.message) setStatus(latestWorkerState.message, false, { fromBatch: true });
      return;
    }
    render(resp.queue, resp.state);
  } else {
    setStatus(resp.error || 'Không đọc được trạng thái hàng chờ.', true);
  }
}

async function saveEditedCell(rowId, header, value) {
  let updates = {};
  if (header === '_state') {
    updates.status = value;
    if (value === 'pending') {
      updates.error = '';
      updates.sentAt = 0;
      updates.replies = [];
    } else if (value === 'wait_reply') {
      updates.error = '';
      updates.sentAt = Date.now();
    }
  } else if (header === 'wait_reply') {
    updates.values = { wait_reply: value };
  } else {
    updates.values = { [header]: value };
  }

  const resp = await sendMessage({ type: 'UPDATE_ROW', rowId, updates });
  if (!resp.ok) throw new Error(resp.error || 'Không cập nhật được ô.');
  await pollStatus();
}

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(pollStatus, 1000);
}

async function importBatchFromFile(file) {
  setStatus('Đang đọc file...');
  let parsed = { headers: [], rows: [] };
  
  if (file.name.match(/\.xlsx?$|\.xls$/i)) {
    const buffer = await readFileAsArrayBuffer(file);
    const wb = XLSX.read(buffer, { type: 'array', cellDates: true, dateNF: 'yyyy-mm-dd hh:mm' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(ws, { defval: '', raw: false, dateNF: 'yyyy-mm-dd hh:mm' });
    if (json.length > 0) {
      parsed.headers = Object.keys(json[0]);
      parsed.rows = json;
    }
  } else {
    const text = await readFileAsText(file);
    parsed = ZZCsv.parseCsv(text);
  }

  parsed = normalizeParsedColumns(parsed);

  const missing = ['message'].filter((name) => !parsed.headers.includes(name));
  if (missing.length) {
    throw new Error(`File thiếu cột bắt buộc: ${missing.join(', ')}.`);
  }
  if (!parsed.rows.length) {
    throw new Error('File không có dòng dữ liệu.');
  }

  const rows = parsed.rows
    .filter((row, index) => index !== 0 || !isTemplateNoteRow(row))
    .filter(hasData);
  validateRowsHaveMessage(rows);
  if (!rows.length) {
    throw new Error('File import không chứa dữ liệu thực tế.');
  }

  // Kiểm tra trùng lắp ZID/SĐT với hàng chờ hiện tại
  const queueResp = await sendMessage({ type: 'GET_QUEUE' });
  if (!queueResp.ok) throw new Error(queueResp.error || 'Không đọc được hàng chờ.');

  const existingQueue = queueResp.queue || { byId: {}, headers: [] };
  const existingRows = Object.values(existingQueue.byId).map((r) => ({
    ...r.values,
    _status: r.status
  }));

  const mergedRows = mergeImportedRows(existingRows, rows);
  if (!mergedRows) {
    setStatus('Đã hủy import.');
    return;
  }

  // Hiển thị hộp xác nhận thêm dòng
  const onlyNewRows = rows.filter((r) => !existingRows.some((e) => getRowZid(e) && getRowZid(e) === getRowZid(r)));
  if (!confirm(buildImportConfirmText(onlyNewRows.length ? onlyNewRows : rows, rows.length))) {
    setStatus('Đã hủy import.');
    return;
  }

  // Thêm dữ liệu vào background queue
  const addResp = await sendMessage({
    type: 'ADD_ROWS',
    rows,
    headers: parsed.headers
  });

  if (!addResp.ok) {
    throw new Error(addResp.error || 'Không thêm được dòng vào hàng chờ.');
  }

  setStatus(`Đã import thành công ${rows.length} dòng.`);
  await pollStatus();
}

async function startWorkerProcessing() {
  const resp = await sendMessage({ type: 'START_WORKER' });
  if (!resp.ok) throw new Error(resp.error || 'Không khởi động được worker.');
  
  setStatus('Hàng chờ đang hoạt động.');
  await pollStatus();
}

async function startFromPendingImport() {
  // Tải dữ liệu hàng chờ lúc khởi chạy
  await pollStatus();
  startPolling();
}

importBtn.addEventListener('click', () => {
  csvFileInput.value = '';
  csvFileInput.click();
});

statusCloseBtn.addEventListener('click', clearStatus);

templateBtn.addEventListener('click', () => {
  downloadXlsx('zalo-upload-template.xlsx', TEMPLATE_HEADERS, [TEMPLATE_NOTE_ROW]);
});

csvFileInput.addEventListener('change', async () => {
  const file = csvFileInput.files?.[0];
  if (!file) return;

  try {
    await importBatchFromFile(file);
  } catch (err) {
    setStatus(err?.message || 'Import lỗi.', true);
  }
});

startBtn.addEventListener('click', async () => {
  try {
    await startWorkerProcessing();
  } catch (err) {
    setStatus(err?.message || 'Không bắt đầu được worker.', true);
  }
});

exportBtn.addEventListener('click', () => {
  if (!latestQueue || !Object.keys(latestQueue.byId).length) return;
  downloadXlsx(
    `zalo-queue-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.xlsx`,
    orderHeaders(latestQueue.headers),
    buildExportRows(latestQueue)
  );
  setStatus('Đã export XLSX.');
});

clearBtn.addEventListener('click', async () => {
  if (!confirm('Bạn có chắc chắn muốn xóa sạch toàn bộ hàng chờ tin nhắn không?')) return;
  try {
    if (latestWorkerState?.running) {
      await sendMessage({ type: 'STOP_WORKER' });
    }
    const resp = await sendMessage({ type: 'CLEAR_QUEUE' });
    if (!resp.ok) throw new Error(resp.error || 'Không xóa được hàng chờ.');
    
    render(resp.queue, null);
    setStatus('Đã xóa sạch hàng chờ tin nhắn.');
  } catch (err) {
    setStatus(err?.message || 'Không xóa được bảng.', true);
  }
});

stopBtn.addEventListener('click', async () => {
  try {
    const resp = await sendMessage({ type: 'PAUSE_WORKER' });
    if (!resp.ok) throw new Error(resp.error || 'Không thể tạm dừng.');
    
    setStatus('Đã tạm dừng.');
    await pollStatus();
  } catch (err) {
    setStatus(err?.message || 'Không tạm dừng được worker.', true);
  }
});

endBtn.addEventListener('click', async () => {
  if (!confirm('Bạn có chắc chắn muốn kết thúc hàng chờ này? Tất cả các dòng đang chờ phản hồi sẽ chuyển sang trạng thái Hoàn tất.')) return;
  try {
    const resp = await sendMessage({ type: 'STOP_WORKER' });
    if (!resp.ok) throw new Error(resp.error || 'Không dừng được worker.');
    
    setStatus('Đã dừng và hoàn tất hàng chờ.');
    await pollStatus();
  } catch (err) {
    setStatus(err?.message || 'Không dừng được worker.', true);
  }
});

window.addEventListener('beforeunload', () => {
  if (pollTimer) clearInterval(pollTimer);
});

if (searchInput) {
  searchInput.addEventListener('input', () => {
    if (latestQueue && latestWorkerState) render(latestQueue, latestWorkerState);
  });
}

if (statusFilter) {
  statusFilter.addEventListener('change', () => {
    if (latestQueue && latestWorkerState) render(latestQueue, latestWorkerState);
  });
}

bodyEl.addEventListener('focusin', (ev) => {
  const stateSelect = ev.target.closest('select.state-select');
  if (stateSelect) {
    stateSelectActive = true;
    return;
  }

  const cell = ev.target.closest('td[contenteditable="true"]');
  if (!cell) return;
  editingCell = {
    rowId: cell.dataset.rowId,
    header: cell.dataset.header,
    original: cell.innerText
  };
});

bodyEl.addEventListener('change', async (ev) => {
  const checkbox = ev.target.closest('input.wait-reply-check');
  if (checkbox) {
    const rowId = checkbox.dataset.rowId;
    try {
      await saveEditedCell(rowId, 'wait_reply', checkbox.checked ? 'x' : '');
    } catch (err) {
      setStatus(err?.message || 'Không cập nhật được wait_reply.', true);
      if (latestQueue && latestWorkerState) render(latestQueue, latestWorkerState);
    }
    return;
  }

  const select = ev.target.closest('select.state-select');
  if (!select) return;
  const rowId = select.dataset.rowId;
  try {
    await saveEditedCell(rowId, '_state', select.value);
    stateSelectActive = false;
  } catch (err) {
    setStatus(err?.message || 'Không cập nhật được trạng thái.', true);
    stateSelectActive = false;
    if (latestQueue && latestWorkerState) render(latestQueue, latestWorkerState);
  }
});

document.addEventListener('mousedown', (ev) => {
  if (!ev.target.closest?.('select.state-select')) {
    stateSelectActive = false;
  }
});

bodyEl.addEventListener('keydown', (ev) => {
  const cell = ev.target.closest('td[contenteditable="true"]');
  if (!cell) return;
  if (ev.key === 'Enter' && !ev.shiftKey) {
    ev.preventDefault();
    cell.blur();
  }
});

bodyEl.addEventListener('focusout', async (ev) => {
  const cell = ev.target.closest('td[contenteditable="true"]');
  if (!cell || !editingCell) return;

  const rowId = editingCell.rowId;
  const header = editingCell.header;
  const value = cell.innerText.replace(/\r/g, '').trim();
  const original = editingCell.original.replace(/\r/g, '').trim();
  editingCell = null;

  if (!rowId || !header || value === original) return;

  try {
    await saveEditedCell(rowId, header, value);
  } catch (err) {
    setStatus(err?.message || 'Không cập nhật được ô.', true);
    if (latestQueue && latestWorkerState) render(latestQueue, latestWorkerState);
  }
});

applyModeUi();
startFromPendingImport();
