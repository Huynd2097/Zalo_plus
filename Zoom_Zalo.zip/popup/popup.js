const sendMessageBtn = document.getElementById('sendMessageBtn');
const contactsBtn = document.getElementById('contactsBtn');
const statusEl = document.getElementById('status');

function setStatus(text, isError = false) {
  statusEl.textContent = text;
  statusEl.style.color = isError ? '#dc2626' : '#334155';
}

function openTab(url) {
  return new Promise((resolve) => chrome.tabs.create({ url }, resolve));
}

async function openExtensionPage(path, label) {
  try {
    setStatus(`Đang mở ${label}...`);
    await openTab(chrome.runtime.getURL(path));
    window.close();
  } catch (err) {
    setStatus(err?.message || `Không mở được ${label}.`, true);
  }
}

sendMessageBtn.addEventListener('click', () => {
  openExtensionPage('batch-page/send_message.html', 'Gửi tin nhắn');
});

contactsBtn.addEventListener('click', () => {
  openExtensionPage('contacts-page/contacts.html', 'Liên hệ');
});
