# Tài liệu Tiến trình Tối giản hóa Giao diện Z-Campaigner AI (Tháng 06/2026)

Tài liệu này ghi lại các thay đổi thiết kế giao diện (UI/UX) theo hướng tối giản, sạch sẽ, tối ưu hóa trải nghiệm người dùng dựa trên bản mẫu thiết kế được cung cấp.

---

## 1. Các thành phần giao diện cũ đã lược bỏ/ẩn đi (Legacy UI Cleanup)

Để tránh làm nhiễu thông tin hiển thị và giúp giao diện gọn gàng hơn, các nút sau đã được ẩn (`hidden`) khỏi giao diện chính của Dashboard:
*   **Tải template** (`templateBtn`): Không hiển thị trên bảng hàng chờ.
*   **Nhập từ CSV/XLSX** (`importBtn`): Không hiển thị trên bảng hàng chờ.
*   **Reset hàng loạt** (`bulkResetBtn`): Ẩn khỏi thanh công cụ hàng loạt.
*   **Làm trống hàng chờ** (`clearQueueBtn`): Ẩn để đảm bảo tính an toàn dữ liệu và tối giản bảng.

*Lưu ý: Các hàm logic nền tảng xử lý nhập file, reset, xóa sạch vẫn được giữ lại trong các mô-đun để bảo đảm tính tương thích kỹ thuật, nhưng không hiển thị nút ra ngoài giao diện.*

---

## 2. Tái sắp xếp cấu trúc các Bảng dữ liệu (Table Layout Reorganization)

### Bảng Cơ sở dữ liệu Danh bạ (Contacts Database Table)
*   **Lược bỏ các từ khóa lập trình**: Đổi tiêu đề cột từ dạng biến lập trình (`display_name`, `zid`, `sys_phone`) sang tiếng Việt rõ nghĩa cho người dùng ("Tên hiển thị", "Zalo ID", "SĐT hệ thống").
*   **Di chuyển các cột kỹ thuật về cuối**: Cột **Zalo ID (zid)** và **SĐT hệ thống (sys_phone)** được đưa xuống cuối bảng (ngay trước cột Xóa) để người dùng tập trung vào các thông tin quan trọng như Tên hiển thị, Số điện thoại và Nhãn.
*   **Lược bỏ cột Cập nhật**: Cột hiển thị thời gian cập nhật liên hệ đã được loại bỏ hoàn toàn khỏi bảng danh bạ.

### Bảng Hàng chờ gửi tin (Queue Table)
*   Đồng bộ thứ tự cột theo thứ tự hiển thị tự nhiên của thông tin:
    1.  Checkbox chọn dòng.
    2.  Trạng thái gửi.
    3.  Nhóm (Tag) dạng nhãn chữ màu.
    4.  Tên hiển thị.
    5.  Số điện thoại khách hàng.
    6.  Nội dung tin nhắn gửi đi.
    7.  Khách phản hồi (Nội dung phản hồi thu thập được).
    8.  Thời gian hẹn giờ/Thời gian gửi.
    9.  Nút gửi ngay / Trạng thái chờ.
    10. Lỗi hệ thống nếu có.

---

## 3. Tối ưu hóa Quản lý Nhãn & Màu sắc (Tag & Color Optimization)

*   **Bỏ bộ chọn màu đơn lẻ tại từng dòng danh bạ**: Loại bỏ thẻ `<input type="color">` bên cạnh tên tag trong danh sách hiển thị danh bạ. Màu sắc của nhãn hiện tại được phản ánh trực tiếp qua màu chữ (`style="color: ...;"`) của chính nhãn đó, giúp giao diện không bị vụn vặt và rối mắt.
*   **Nút đổi màu nhãn tập trung**: Bổ sung nút **Đổi màu nhãn** (`updateTagColorBtn`) ngay bên cạnh nút **Gắn nhãn** (`applyTagBtn`) ở khu vực thiết lập tag hàng loạt. Người dùng nhập tên nhãn, chọn màu sắc đại diện và bấm nút này để cập nhật đồng loạt màu sắc của nhãn đó cho toàn bộ danh bạ.

---

## 4. Sửa lỗi Đồng bộ và Hiển thị Checkbox (UI State Synchronization Fixes)

*   **Sửa lỗi ẩn checkmark icon của checkbox**: Thêm CSS rule `.peer:checked ~ div i { display: block !important; }` vào trong thẻ `<style>` của `main.html` để đảm bảo biểu tượng checkmark (`<i>`) được hiển thị chính xác khi checkbox ẩn dạng `peer` được tích chọn.
*   **Sửa lỗi click một người chọn tất cả danh bạ**: Khắc phục hiện tượng trùng khóa (`key === undefined`) khi liên hệ thiếu cả 3 thông tin `phone`, `sys_phone`, và `zid`. Hệ thống đã tự động bổ sung fallback dùng `display_name` làm khóa định danh duy nhất cho hàng chờ và danh sách nhận tin, giúp việc tích chọn hàng độc lập và chính xác tuyệt đối.
*   **Tối ưu độ rộng bảng hàng chờ**: Cấu trúc lại trang để chỉ riêng phần bảng hàng chờ gửi tin (`BẢNG HÀNG CHỜ GỬI`) trải rộng toàn màn hình (`w-full px-2 sm:px-4`) với lề cực nhỏ, giúp theo dõi thông tin hàng đợi rộng rãi và thoải mái hơn. Các thành phần khác như thanh tiêu đề, bộ lọc, trình soạn thảo, và Tab Danh bạ vẫn duy trì giới hạn độ rộng (`max-w-7xl`) với lề to như cũ để giữ tính cân đối cho giao diện.
