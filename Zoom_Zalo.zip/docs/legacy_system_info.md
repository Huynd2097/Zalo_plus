# Thông tin Hệ thống Đa trang Cũ (Legacy Multi-page System)

Tài liệu này lưu trữ thông tin về kiến trúc hệ thống giao diện cũ của extension, vốn đã được xóa bỏ hoàn toàn từ phiên bản tháng 06/2026 để chuyển dịch sang giao diện hợp nhất **main-page** (Z-Campaigner AI Dashboard).

---

## 1. Cấu trúc Thư mục Hệ thống Cũ (Đã xóa)

Trước khi thực hiện hợp nhất, extension sử dụng cấu trúc đa trang riêng biệt để quản lý gửi tin và danh bạ:

```
├── batch-page/
│   ├── send_message.html   # Giao diện gửi tin nhắn hàng loạt theo đợt
│   └── send_message.js     # Logic xử lý và tải tệp CSV gửi tin
├── contacts-page/
│   ├── contacts.html       # Giao diện hiển thị danh sách danh bạ Zalo
│   └── contacts.js         # Logic đồng bộ và gán tag cho liên hệ
```

---

## 2. Cách thức Hoạt động Cũ và Hạn chế

1. **Popup Điều hướng:**
   * Popup extension (`popup.html`) trước đây đóng vai trò như một menu điều hướng đơn giản chứa hai đường link dẫn tới `batch-page/send_message.html` và `contacts-page/contacts.html`.
   * Người dùng phải thao tác mở hai tab trình duyệt khác nhau để vừa quản lý danh bạ vừa chạy chiến dịch gửi tin.

2. **Lưu trữ Trạng thái Riêng biệt:**
   * Trạng thái gửi tin nhắn hàng loạt (`activeBatch`) được lưu riêng và phụ thuộc vào vòng đời của trang `send_message.html`. Nếu người dùng vô tình đóng tab này, chiến dịch gửi tin có thể bị gián đoạn.
   * Danh bạ được đồng bộ thủ công từ trang `contacts.html` và lưu vào `zaloContacts` mà không có sự liên kết chặt chẽ hay đồng bộ thời gian thực với hàng chờ gửi tin.

3. **Thiếu Tích hợp AI:**
   * Hệ thống cũ không tích hợp các tính năng AI hỗ trợ như chuẩn hóa danh bạ, tự động viết kịch bản, và tối ưu hóa tone giọng tin nhắn.

---

## 3. Lý do Thay thế & Chuyển đổi

Để cải thiện trải nghiệm người dùng (UX) và tối ưu hiệu năng của Extension, toàn bộ mã nguồn cũ tại `batch-page/` và `contacts-page/` đã được loại bỏ. Các tính năng của chúng đã được nâng cấp và tích hợp vào tab **Chiến dịch** và **Danh bạ** của giao diện hợp nhất [main.html](file:///d:/Source_Code/Js/Zoom_Zalo/main-page/main.html).
