# Tài liệu Kiến trúc Hệ thống Hàng chờ (Queue-based Architecture)

Tài liệu này mô tả chi tiết việc chuyển đổi hệ thống gửi tin nhắn Zalo từ kiến trúc **Batch nguyên khối (Monolithic Batch)** sang kiến trúc **Hàng chờ và Worker độc lập (Queue-based Worker)**.

---

## 1. Lý do chuyển đổi (Từ Batch sang Queue)

| Đặc điểm | Kiến trúc cũ (Batch) | Kiến trúc mới (Queue-based) |
|---|---|---|
| **Quản lý dữ liệu** | Toàn bộ dữ liệu nằm trong 1 đối tượng JSON lớn (`activeBatch`) chứa cả headers, cấu hình và danh sách dòng. | Mỗi dòng là một bản ghi độc lập (`byId`) lưu trong hàng chờ `messageQueue` ở `chrome.storage.local`. |
| **Ghi đè & Đồng bộ** | Khi cập nhật 1 dòng, hệ thống phải ghi lại toàn bộ cục JSON lớn → Có nguy cơ xung đột dữ liệu (data corruption) và hiệu năng kém khi số dòng lớn. | Hỗ trợ cập nhật chính xác từng dòng theo ID (`rowId`). Dữ liệu UI và Worker độc lập và không sợ ghi đè chéo. |
| **Sự linh hoạt** | Không thể thêm/bớt/chỉnh sửa dòng khi hệ thống đang chạy gửi tin. | Có thể CRUD (thêm dòng mới, xóa dòng, sửa nội dung/trạng thái dòng) bất cứ lúc nào, kể cả khi Worker đang gửi tin. |
| **Trạng thái Worker** | Trạng thái đồng bộ và gửi tin nhắn ràng buộc chặt chẽ với vòng đời của trang Batch UI. | Worker hoạt động ngầm (Service Worker background) độc lập, tự động khôi phục chạy tiếp nếu Service Worker bị Chrome giải phóng (restart). |

---

## 2. Cấu trúc dữ liệu trong Storage

### 2.1 Hàng chờ tin nhắn (`messageQueue`)
Được lưu trong `chrome.storage.local` với khóa `'messageQueue'`.
```json
{
  "byId": {
    "row-1717300000-a1b2": {
      "id": "row-1717300000-a1b2",
      "values": {
        "name": "Nguyễn Văn A",
        "phone": "0987654321",
        "message": "Xin chào!",
        "send_at": "",
        "wait_reply": "x",
        "zid": "4823571762402856934",
        "display_name": "Nguyễn Văn A",
        "tag": "Công việc",
        "sys_phone": "987654321"
      },
      "status": "pending",
      "error": "",
      "replies": [],
      "sentAt": 0,
      "createdAt": 1717300000000,
      "updatedAt": 1717300000000
    }
  },
  "headers": ["name", "phone", "message", "send_at", "wait_reply", "zid"]
}
```

### 2.2 Trạng thái của Worker (`workerState`)
Được lưu với khóa `'workerState'`.
```json
{
  "running": false,
  "phase": "idle",
  "currentRowId": null,
  "currentWait": {
    "rowId": "row-1717300000-a1b2",
    "zid": "4823571762402856934",
    "display_name": "Nguyễn Văn A",
    "tag": "Công việc"
  },
  "message": "",
  "updatedAt": 1717300000000
}
```

---

## 3. Các hàm xử lý cốt lõi trong Background

### 3.1 Quản lý hàng chờ (`background/queue.js`)

*   `generateRowId()`
    *   *Chức năng*: Tạo ID ngẫu nhiên, duy nhất cho từng dòng trong hàng chờ dựa trên thời gian thực tế.
*   `loadQueue()`
    *   *Chức năng*: Đọc dữ liệu hàng chờ `messageQueue` từ storage. Trả về cấu trúc mặc định nếu chưa tồn tại.
*   `saveQueue(queue)`
    *   *Chức năng*: Lưu trữ hàng chờ đã thay đổi vào storage và thực hiện dọn dẹp (xóa các dòng có trạng thái `done` hoặc `error` quá 7 ngày để tránh đầy bộ nhớ extension).
*   `addRowsToQueue(rows, headers)`
    *   *Chức năng*: Thêm danh sách dòng mới vào hàng chờ. Tự động trích xuất và chuẩn hóa số điện thoại (từ cột phone hoặc từ tên hiển thị nếu cột phone trống), dọn dẹp thông tin và bổ sung các cột ẩn.
*   `updateQueueRow(rowId, updates)`
    *   *Chức năng*: Cập nhật thuộc tính của một dòng (chỉ cập nhật nội dung được thay đổi) qua cơ chế đọc-sửa-ghi nguyên tử (atomic read-modify-write) để tránh xung đột ghi đè.
*   `removeQueueRows(ids)`
    *   *Chức năng*: Xóa danh sách các dòng ra khỏi hàng chờ dựa trên mảng các `rowId`.
*   `clearQueue()`
    *   *Chức năng*: Xóa sạch toàn bộ dữ liệu hàng chờ trong bộ nhớ.
*   `getQueueSummary()`
    *   *Chức năng*: Thống kê số lượng dòng theo trạng thái (`pending`, `sending`, `done`, `error`) để hiển thị tóm tắt tiến trình gửi tin lên giao diện.
*   `migrateFromBatchToQueue()`
    *   *Chức năng*: Tự động đọc dữ liệu `activeBatch` của phiên bản cũ (nếu có) để di cư sang cấu trúc `messageQueue` mới khi người dùng cập nhật extension, sau đó xóa bỏ khóa cũ.

### 3.2 Luồng xử lý Worker (`background/worker.js`)

*   `ensureZaloTab()`
    *   *Chức năng*: Kiểm tra xem tab Zalo (`chat.zalo.me`) đã mở chưa. Nếu chưa có, tiến hành mở tab mới và active nó.
*   `openZaloChat(tabId, zid)`
    *   *Chức năng*: Mở cuộc hội thoại dựa trên `zid`. Thuật toán ưu tiên tìm kiếm tọa độ của hội thoại hiển thị ở sidebar để click trực tiếp nhằm tránh tải lại trang. Nếu không thấy, hệ thống sẽ thực hiện fallback điều hướng tab sang URL `chat.zalo.me/?c=zid`.
*   `readCurrentChatInfo(tabId)`
    *   *Chức năng*: Đọc tên hiển thị và thẻ nhãn (tag) hiện tại của cuộc trò chuyện đang active trên DOM Zalo.
    *   *Đặc biệt*: **Tự động đồng bộ display_name**: Hàm này so sánh `display_name` thực tế trên DOM với dữ liệu lưu trong danh bạ liên hệ (`zaloContactMap`). Nếu phát hiện có sự thay đổi (ví dụ: người dùng đổi tên Zalo hoặc sửa biệt danh), hàm sẽ tự động cập nhật lại cơ sở dữ liệu `zaloContactMap` để giữ đồng bộ.
*   `sendQueueRow(tabId, row)`
    *   *Chức năng*: Thực hiện gửi tin cho một dòng cụ thể: Xác định ZID (tìm kiếm SĐT nếu chưa có ZID) → Mở chat → Xác minh đúng người nhận → Gõ tin nhắn và click gửi bằng lệnh gỡ lỗi Chrome Debugger (CDP) → Lưu ánh xạ liên hệ → Chuyển trạng thái dòng thành `wait_reply` hoặc `done`.
*   `pollQueueReplies(tabId)`
    *   *Chức năng*: Lọc danh sách các dòng có trạng thái `wait_reply` và định kỳ dò quét tin nhắn phản hồi mới từ đối phương trên DOM Zalo, giới hạn tối đa thu thập 5 tin phản hồi mỗi dòng.
*   `runWorkerLoop(tabId)`
    *   *Chức năng*: Vòng lặp chính của worker:
        1. Tìm dòng `pending` cần gửi tức thời và gọi `sendQueueRow`.
        2. Nếu không có dòng tức thời, kiểm tra xem có dòng nào hẹn giờ trong tương lai (`send_at`) để tạm dừng chờ đến giờ.
        3. Nếu không còn tin nhắn chờ gửi, chuyển sang chế độ theo dõi phản hồi (`phase = 'polling'`) và gọi `pollQueueReplies`.
        4. Tự động thoát và giải phóng debugger khi hoàn thành toàn bộ công việc.
*   `startWorker(waitReplyTabId)`
    *   *Chức năng*: Kích hoạt chạy worker. Khởi tạo debugger CDP, chuyển trạng thái `workerState.running = true` và bắt đầu chạy `runWorkerLoop` bất đồng bộ.
*   `pauseWorker()`
    *   *Chức năng*: Chuyển trạng thái worker sang tạm dừng (`phase = 'paused'`). Vòng lặp của worker sẽ nhận diện và thoát khỏi tiến trình một cách an toàn mà không làm mất trạng thái của các dòng.
*   `stopWorker()`
    *   *Chức năng*: Dừng hoàn toàn worker, giải phóng kết nối debugger và chuyển tất cả các dòng đang chờ phản hồi (`wait_reply`) sang trạng thái kết thúc (`done`).

---

## 4. Cách thức Phối hợp và Luồng Sự kiện

```mermaid
sequenceDiagram
    participant UI as Giao diện (batch-page)
    participant SW as Service Worker (background)
    participant ZD as Trình duyệt Zalo DOM

    UI->>SW: Gửi tin nhắn (START_WORKER)
    Note over SW: workerState.running = true
    SW->>SW: Đọc hàng chờ (loadQueue)
    SW->>ZD: Tìm & mở cuộc hội thoại (ZID/SĐT)
    SW->>ZD: Gửi tin nhắn qua CDP Debugger
    SW->>SW: Cập nhật dòng (status = wait_reply/done)
    SW->>UI: Đồng bộ trạng thái hàng chờ (GET_QUEUE)
    
    Note over ZD: Đối phương nhắn tin trả lời
    SW->>ZD: Định kỳ đọc phản hồi (pollQueueReplies)
    SW->>SW: Cập nhật replies của dòng & lưu danh bạ
    SW->>UI: Đồng bộ replies lên bảng hiển thị
```

## 5. Các Sự cố Đặc thù & Cơ chế Tự sửa lỗi (Troubleshooting & Self-Healing)

### 5.1 Lỗi lệch ZID khi tìm kiếm SĐT (Stale ZID Mapping)
*   **Triệu chứng:** Khi gửi tin nhắn tìm kiếm theo số điện thoại, giao diện `batch-page/send_message` hiển thị sai `zid` của người nhận (thường bị trỏ về `zid` của tài khoản hệ thống như "My Documents" / Truyền file).
*   **Nguyên nhân:** Do Zalo chuyển trang chậm sau khi click kết quả tìm kiếm, hàm trích xuất dữ liệu đọc nhầm thông tin của cuộc hội thoại cũ đang hiển thị trước đó. Bản ghi bị lỗi này được lưu vào danh bạ và làm sai lệch chỉ mục tra cứu số điện thoại.
*   **Giải pháp xử lý:**
    1.  **Chờ chuyển trang thực tế:** Hệ thống kiểm tra tiêu đề cuộc chat (`#header .header-title`) cho tới khi khớp với tên kết quả tìm kiếm mới tiến hành lấy `zid`.
    2.  **Bảo vệ tài khoản hệ thống:** Các tài khoản đặc biệt (`My Documents`, `Truyền file`, `Cloud của tôi`, `Zalo`) được cấu hình bỏ qua việc trích xuất số điện thoại, nhãn và tên riêng để tránh bị ghi nhiễm chéo.
    3.  **Tự chữa lành danh bạ (Self-Healing):** Mỗi lần cơ sở dữ liệu danh bạ được tải lên qua hàm `loadContactMap()`, hệ thống sẽ tự động quét, xóa sạch dữ liệu lỗi của tài khoản hệ thống và tái cấu trúc lại toàn bộ chỉ mục tra cứu để loại bỏ các liên kết sai lệch.

